"use client"

import  from "../options"

export default function SyntheticV0PageForDeployment() {
  return < />
}